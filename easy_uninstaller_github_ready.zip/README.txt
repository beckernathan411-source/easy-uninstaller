Easy Uninstaller Premium 3.0

Description
-----------
Easy Uninstaller Premium est un logiciel Windows en Python qui lit le registre
Windows pour afficher les programmes installés et lancer leur désinstallation
officielle plus facilement.

Fonctions
---------
- Interface premium avec barre latérale
- Recherche instantanée
- Tri par colonnes
- Filtres Tous / Machine / Utilisateur
- Masquer Microsoft
- Masquer les mises à jour système
- Désinstallation simple ou multiple
- Copie du nom et de la commande
- Ouverture du dossier d'installation
- Export CSV
- Icône simple fournie

Important
---------
- Compatible Windows uniquement
- Le logiciel ne force pas la suppression des fichiers
- Il exécute les commandes de désinstallation déjà enregistrées par Windows
- Certaines désinstallations demandent les droits administrateur

Lancer le projet
----------------
1. Installer Python 3 sur Windows
2. Ouvrir un terminal dans ce dossier
3. Lancer :
   python main.py

Créer le .exe
-------------
Double-cliquer sur :
   build_exe.bat

Le fichier généré sera normalement ici :
   dist\EasyUninstallerPremium.exe

Commande manuelle
-----------------
py -m pip install --upgrade pip pyinstaller
py -m PyInstaller --noconfirm --clean --onefile --windowed --icon=app_icon.ico --name EasyUninstallerPremium main.py
