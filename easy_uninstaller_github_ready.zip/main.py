import csv
import os
import queue
import re
import subprocess
import threading
import tkinter as tk
from dataclasses import dataclass
from tkinter import filedialog, messagebox, ttk

try:
    import winreg
except ImportError:
    winreg = None

APP_TITLE = "Easy Uninstaller Premium"
APP_VERSION = "3.0"

WINDOW_BG = "#0b1020"
SURFACE_BG = "#121a2f"
PANEL_BG = "#111827"
CARD_BG = "#0f172a"
SIDEBAR_BG = "#0a0f1e"
TOPBAR_BG = "#0c1326"
ACCENT = "#4f8cff"
ACCENT_2 = "#32d296"
ACCENT_3 = "#b388ff"
TEXT = "#e8edf8"
MUTED = "#95a3c4"
BORDER = "#26314e"
ROW_BASE = "#0f172a"
ROW_ALT = "#111d35"
WARNING = "#f59e0b"


@dataclass
class ProgramEntry:
    name: str
    version: str
    publisher: str
    uninstall_cmd: str
    quiet_cmd: str
    install_location: str
    scope: str
    registry_key: str
    estimated_size_mb: float | None = None

    def effective_uninstall_command(self) -> str:
        return (self.quiet_cmd or "").strip() or (self.uninstall_cmd or "").strip()

    @property
    def has_uninstall(self) -> bool:
        return bool(self.effective_uninstall_command())

    def size_label(self) -> str:
        if self.estimated_size_mb is None:
            return "Inconnue"
        if self.estimated_size_mb >= 1024:
            return f"{self.estimated_size_mb / 1024:.1f} Go"
        return f"{self.estimated_size_mb:.0f} Mo"


class InfoCard(tk.Frame):
    def __init__(self, master, title: str, value: str, subtitle: str, accent: str):
        super().__init__(master, bg=CARD_BG, highlightthickness=1, highlightbackground=BORDER)
        self.configure(padx=14, pady=14)
        accent_bar = tk.Frame(self, bg=accent, width=5)
        accent_bar.pack(side="left", fill="y", padx=(0, 12))
        content = tk.Frame(self, bg=CARD_BG)
        content.pack(side="left", fill="both", expand=True)
        tk.Label(content, text=title, bg=CARD_BG, fg=MUTED, font=("Segoe UI", 9, "bold")).pack(anchor="w")
        self.value_label = tk.Label(content, text=value, bg=CARD_BG, fg=TEXT, font=("Segoe UI", 18, "bold"))
        self.value_label.pack(anchor="w", pady=(4, 0))
        self.subtitle_label = tk.Label(content, text=subtitle, bg=CARD_BG, fg=accent, font=("Segoe UI", 9))
        self.subtitle_label.pack(anchor="w", pady=(4, 0))

    def update_values(self, value: str, subtitle: str):
        self.value_label.config(text=value)
        self.subtitle_label.config(text=subtitle)


class PremiumButton(tk.Label):
    def __init__(self, master, text: str, command, active=False):
        bg = ACCENT if active else SIDEBAR_BG
        fg = "white" if active else TEXT
        super().__init__(
            master,
            text=text,
            bg=bg,
            fg=fg,
            font=("Segoe UI", 10, "bold"),
            padx=14,
            pady=10,
            cursor="hand2",
            anchor="w",
        )
        self.default_bg = bg
        self.hover_bg = "#172447" if not active else ACCENT
        self.command = command
        self.bind("<Button-1>", lambda _e: self.command())
        self.bind("<Enter>", lambda _e: self.config(bg=self.hover_bg))
        self.bind("<Leave>", lambda _e: self.config(bg=self.default_bg))


class UninstallerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_TITLE} {APP_VERSION}")
        self.geometry("1540x900")
        self.minsize(1280, 760)
        self.configure(bg=WINDOW_BG)

        self.programs: list[ProgramEntry] = []
        self.filtered_programs: list[ProgramEntry] = []
        self.row_to_program: dict[str, ProgramEntry] = {}
        self.worker_queue: queue.Queue = queue.Queue()
        self.sort_column = "name"
        self.sort_reverse = False

        self.search_var = tk.StringVar()
        self.status_var = tk.StringVar(value="Prêt")
        self.only_with_uninstall_var = tk.BooleanVar(value=True)
        self.hide_updates_var = tk.BooleanVar(value=True)
        self.hide_microsoft_var = tk.BooleanVar(value=False)
        self.scope_var = tk.StringVar(value="Tous")
        self.selection_count_var = tk.StringVar(value="0 sélection")
        self.details_title_var = tk.StringVar(value="Aucun programme sélectionné")
        self.details_var = tk.StringVar(value="Sélectionne un programme pour afficher ses informations détaillées.")
        self.quick_stats_var = tk.StringVar(value="0 programme affiché")

        self._configure_style()
        self._build_ui()
        self.after(120, self._poll_worker_queue)
        self.refresh_programs()

    def _configure_style(self):
        style = ttk.Style(self)
        if "clam" in style.theme_names():
            style.theme_use("clam")

        style.configure(
            "Treeview",
            background=ROW_BASE,
            fieldbackground=ROW_BASE,
            foreground=TEXT,
            rowheight=34,
            borderwidth=0,
            font=("Segoe UI", 10),
        )
        style.map("Treeview", background=[("selected", ACCENT)], foreground=[("selected", "white")])
        style.configure(
            "Treeview.Heading",
            background="#18233f",
            foreground=TEXT,
            font=("Segoe UI", 10, "bold"),
            relief="flat",
            borderwidth=0,
            padding=(10, 10),
        )
        style.map("Treeview.Heading", background=[("active", "#223154")])

        for bar in ("Vertical.TScrollbar", "Horizontal.TScrollbar"):
            style.configure(bar, background="#1a2642", troughcolor="#0a1020", borderwidth=0, arrowsize=13)

        style.configure(
            "Combo.TCombobox",
            fieldbackground="#0f172a",
            background="#0f172a",
            foreground=TEXT,
            arrowcolor=TEXT,
            bordercolor=BORDER,
            lightcolor=BORDER,
            darkcolor=BORDER,
        )
        style.map("Combo.TCombobox", fieldbackground=[("readonly", "#0f172a")], foreground=[("readonly", TEXT)])

    def _build_ui(self):
        shell = tk.Frame(self, bg=WINDOW_BG)
        shell.pack(fill="both", expand=True)

        self._build_sidebar(shell)

        main = tk.Frame(shell, bg=WINDOW_BG)
        main.pack(side="left", fill="both", expand=True)

        self._build_topbar(main)

        content = tk.Frame(main, bg=WINDOW_BG)
        content.pack(fill="both", expand=True, padx=18, pady=(0, 18))

        hero = tk.Frame(content, bg=SURFACE_BG, highlightthickness=1, highlightbackground=BORDER)
        hero.pack(fill="x", pady=(0, 14))
        tk.Label(hero, text="Supprime les programmes installés plus facilement", bg=SURFACE_BG, fg=TEXT, font=("Segoe UI", 21, "bold")).pack(anchor="w", padx=18, pady=(16, 2))
        tk.Label(
            hero,
            text="Recherche, tri, multi-sélection, export CSV, copie des commandes et exécution des désinstallations officielles de Windows.",
            bg=SURFACE_BG,
            fg=MUTED,
            font=("Segoe UI", 10),
        ).pack(anchor="w", padx=18, pady=(0, 8))
        tk.Label(hero, textvariable=self.quick_stats_var, bg=SURFACE_BG, fg=ACCENT_2, font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=18, pady=(0, 16))

        cards = tk.Frame(content, bg=WINDOW_BG)
        cards.pack(fill="x", pady=(0, 14))
        self.card_total = InfoCard(cards, "Programmes visibles", "0", "Liste filtrée", ACCENT)
        self.card_total.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.card_ready = InfoCard(cards, "Désinstallables", "0", "Commandes disponibles", ACCENT_2)
        self.card_ready.pack(side="left", fill="x", expand=True, padx=4)
        self.card_selected = InfoCard(cards, "Sélection", "0", "Aucun élément", WARNING)
        self.card_selected.pack(side="left", fill="x", expand=True, padx=4)
        self.card_size = InfoCard(cards, "Taille estimée", "0 Mo", "Somme visible", ACCENT_3)
        self.card_size.pack(side="left", fill="x", expand=True, padx=(8, 0))

        workspace = tk.Frame(content, bg=WINDOW_BG)
        workspace.pack(fill="both", expand=True)

        center = tk.Frame(workspace, bg=PANEL_BG, highlightthickness=1, highlightbackground=BORDER)
        center.pack(side="left", fill="both", expand=True, padx=(0, 12))

        self._build_toolbar(center)
        self._build_table(center)

        right = tk.Frame(workspace, bg=PANEL_BG, highlightthickness=1, highlightbackground=BORDER, width=380)
        right.pack(side="right", fill="y")
        right.pack_propagate(False)
        self._build_details_panel(right)

        status = tk.Frame(main, bg=TOPBAR_BG, highlightthickness=1, highlightbackground=BORDER)
        status.pack(fill="x", side="bottom")
        tk.Label(status, textvariable=self.status_var, bg=TOPBAR_BG, fg=TEXT, font=("Segoe UI", 10), padx=12, pady=8).pack(side="left")
        tk.Label(status, textvariable=self.selection_count_var, bg=TOPBAR_BG, fg=ACCENT, font=("Segoe UI", 10, "bold"), padx=12, pady=8).pack(side="right")

        self.context_menu = tk.Menu(self, tearoff=0, bg="#0f172a", fg=TEXT, activebackground=ACCENT, activeforeground="white")
        self.context_menu.add_command(label="Désinstaller", command=self.uninstall_selected)
        self.context_menu.add_command(label="Voir la commande", command=self.show_selected_command)
        self.context_menu.add_command(label="Copier la commande", command=self.copy_selected_command)
        self.context_menu.add_command(label="Copier le nom", command=self.copy_selected_name)
        self.context_menu.add_command(label="Ouvrir le dossier", command=self.open_selected_folder)

    def _build_sidebar(self, master):
        sidebar = tk.Frame(master, bg=SIDEBAR_BG, width=245, highlightthickness=1, highlightbackground=BORDER)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        brand = tk.Frame(sidebar, bg=SIDEBAR_BG)
        brand.pack(fill="x", padx=16, pady=(18, 20))
        mark = tk.Canvas(brand, width=44, height=44, bg=SIDEBAR_BG, highlightthickness=0)
        mark.pack(side="left")
        mark.create_oval(2, 2, 42, 42, fill=ACCENT, outline=ACCENT)
        mark.create_text(22, 22, text="EU", fill="white", font=("Segoe UI", 12, "bold"))
        brand_text = tk.Frame(brand, bg=SIDEBAR_BG)
        brand_text.pack(side="left", padx=10)
        tk.Label(brand_text, text="Easy Uninstaller", bg=SIDEBAR_BG, fg=TEXT, font=("Segoe UI", 12, "bold")).pack(anchor="w")
        tk.Label(brand_text, text="Premium 3.0", bg=SIDEBAR_BG, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w")

        block1 = tk.Frame(sidebar, bg=SIDEBAR_BG)
        block1.pack(fill="x", padx=12, pady=(4, 10))
        tk.Label(block1, text="Navigation", bg=SIDEBAR_BG, fg=MUTED, font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=6, pady=(0, 6))
        PremiumButton(block1, "Tableau principal", lambda: self.focus_force(), active=True).pack(fill="x", pady=2)
        PremiumButton(block1, "Actualiser la liste", self.refresh_programs).pack(fill="x", pady=2)
        PremiumButton(block1, "Exporter en CSV", self.export_csv).pack(fill="x", pady=2)

        block2 = tk.Frame(sidebar, bg=SIDEBAR_BG)
        block2.pack(fill="x", padx=12, pady=(8, 10))
        tk.Label(block2, text="Actions rapides", bg=SIDEBAR_BG, fg=MUTED, font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=6, pady=(0, 6))
        PremiumButton(block2, "Désinstaller la sélection", self.uninstall_selected).pack(fill="x", pady=2)
        PremiumButton(block2, "Copier le nom", self.copy_selected_name).pack(fill="x", pady=2)
        PremiumButton(block2, "Copier la commande", self.copy_selected_command).pack(fill="x", pady=2)
        PremiumButton(block2, "Ouvrir le dossier", self.open_selected_folder).pack(fill="x", pady=2)

        note = tk.Frame(sidebar, bg="#0f1730", highlightthickness=1, highlightbackground=BORDER)
        note.pack(fill="x", padx=16, pady=(14, 10))
        tk.Label(note, text="Sécurité", bg="#0f1730", fg=TEXT, font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=12, pady=(10, 4))
        tk.Label(
            note,
            text="L'application lance uniquement les commandes de désinstallation déjà enregistrées par Windows.",
            bg="#0f1730",
            fg=MUTED,
            justify="left",
            wraplength=190,
            font=("Segoe UI", 9),
        ).pack(anchor="w", padx=12, pady=(0, 10))

        bottom = tk.Frame(sidebar, bg=SIDEBAR_BG)
        bottom.pack(side="bottom", fill="x", padx=16, pady=14)
        tk.Label(bottom, text="Aide", bg=SIDEBAR_BG, fg=MUTED, font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(0, 4))
        PremiumButton(bottom, "À propos", self.show_about).pack(fill="x", pady=2)

    def _build_topbar(self, master):
        topbar = tk.Frame(master, bg=TOPBAR_BG, highlightthickness=1, highlightbackground=BORDER)
        topbar.pack(fill="x")
        left = tk.Frame(topbar, bg=TOPBAR_BG)
        left.pack(side="left", fill="x", expand=True, padx=18, pady=14)
        tk.Label(left, text=APP_TITLE, bg=TOPBAR_BG, fg=TEXT, font=("Segoe UI", 14, "bold")).pack(anchor="w")
        tk.Label(left, text="Gestionnaire moderne de désinstallation pour Windows", bg=TOPBAR_BG, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w")

        right = tk.Frame(topbar, bg=TOPBAR_BG)
        right.pack(side="right", padx=18)
        self.search_entry = tk.Entry(
            right,
            textvariable=self.search_var,
            bg="#10182d",
            fg=TEXT,
            insertbackground=TEXT,
            relief="flat",
            font=("Segoe UI", 10),
            width=32,
            highlightthickness=1,
            highlightbackground=BORDER,
            highlightcolor=ACCENT,
        )
        self.search_entry.pack(side="left", ipady=6, pady=14)
        self.search_entry.bind("<KeyRelease>", lambda _e: self.apply_filters())

    def _build_toolbar(self, master):
        toolbar = tk.Frame(master, bg=PANEL_BG)
        toolbar.pack(fill="x", padx=14, pady=14)

        filters = tk.Frame(toolbar, bg=PANEL_BG)
        filters.pack(side="left", fill="x", expand=True)

        tk.Label(filters, text="Portée", bg=PANEL_BG, fg=MUTED, font=("Segoe UI", 9, "bold")).grid(row=0, column=0, sticky="w")
        scope_box = ttk.Combobox(filters, textvariable=self.scope_var, values=["Tous", "Machine", "Utilisateur"], state="readonly", width=14, style="Combo.TCombobox")
        scope_box.grid(row=1, column=0, sticky="w", padx=(0, 12), pady=(4, 0))
        scope_box.bind("<<ComboboxSelected>>", lambda _e: self.apply_filters())

        checks = [
            ("Seulement désinstallables", self.only_with_uninstall_var),
            ("Masquer mises à jour système", self.hide_updates_var),
            ("Masquer Microsoft", self.hide_microsoft_var),
        ]
        for idx, (label, variable) in enumerate(checks, start=1):
            cb = tk.Checkbutton(
                filters,
                text=label,
                variable=variable,
                command=self.apply_filters,
                bg=PANEL_BG,
                fg=TEXT,
                selectcolor="#0f172a",
                activebackground=PANEL_BG,
                activeforeground=TEXT,
                font=("Segoe UI", 10),
            )
            cb.grid(row=1, column=idx, sticky="w", padx=(0, 12), pady=(4, 0))

        actions = tk.Frame(toolbar, bg=PANEL_BG)
        actions.pack(side="right")
        self._make_action_button(actions, "Actualiser", self.refresh_programs, "#1e293b").pack(side="left", padx=4)
        self._make_action_button(actions, "Exporter CSV", self.export_csv, "#1e293b").pack(side="left", padx=4)
        self._make_action_button(actions, "Désinstaller", self.uninstall_selected, ACCENT).pack(side="left", padx=4)

    def _build_table(self, master):
        wrap = tk.Frame(master, bg=PANEL_BG)
        wrap.pack(fill="both", expand=True, padx=14, pady=(0, 14))

        columns = ("name", "version", "publisher", "scope", "size", "location")
        self.tree = ttk.Treeview(wrap, columns=columns, show="headings", selectmode="extended")
        headers = {
            "name": "Programme",
            "version": "Version",
            "publisher": "Éditeur",
            "scope": "Portée",
            "size": "Taille",
            "location": "Dossier d'installation",
        }
        for col, text in headers.items():
            self.tree.heading(col, text=text, command=lambda c=col: self.sort_by_column(c))
        self.tree.column("name", width=300, anchor="w")
        self.tree.column("version", width=120, anchor="w")
        self.tree.column("publisher", width=210, anchor="w")
        self.tree.column("scope", width=95, anchor="center")
        self.tree.column("size", width=90, anchor="e")
        self.tree.column("location", width=430, anchor="w")

        vsb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(wrap, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        wrap.rowconfigure(0, weight=1)
        wrap.columnconfigure(0, weight=1)

        self.tree.tag_configure("even", background=ROW_BASE)
        self.tree.tag_configure("odd", background=ROW_ALT)

        self.tree.bind("<<TreeviewSelect>>", self.on_selection_change)
        self.tree.bind("<Double-1>", lambda _e: self.show_selected_command())
        self.tree.bind("<Button-3>", self.show_context_menu)

    def _build_details_panel(self, master):
        title = tk.Frame(master, bg=PANEL_BG)
        title.pack(fill="x", padx=16, pady=(16, 8))
        tk.Label(title, text="Détails et actions", bg=PANEL_BG, fg=TEXT, font=("Segoe UI", 14, "bold")).pack(anchor="w")
        tk.Label(title, text="Vue détaillée du programme sélectionné", bg=PANEL_BG, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w", pady=(2, 0))

        focus = tk.Frame(master, bg="#0f1730", highlightthickness=1, highlightbackground=BORDER)
        focus.pack(fill="x", padx=16, pady=(0, 12))
        tk.Label(focus, textvariable=self.details_title_var, bg="#0f1730", fg=ACCENT, font=("Segoe UI", 12, "bold"), wraplength=320, justify="left").pack(anchor="w", padx=12, pady=(12, 6))
        tk.Message(focus, textvariable=self.details_var, width=320, bg="#0f1730", fg=TEXT, font=("Segoe UI", 10)).pack(anchor="w", fill="x", padx=12, pady=(0, 12))

        actions = tk.Frame(master, bg=PANEL_BG)
        actions.pack(fill="x", padx=16, pady=(0, 10))
        self._make_action_button(actions, "Désinstaller", self.uninstall_selected, ACCENT, full=True).pack(fill="x", pady=4)
        self._make_action_button(actions, "Voir la commande", self.show_selected_command, "#1e293b", full=True).pack(fill="x", pady=4)
        self._make_action_button(actions, "Copier la commande", self.copy_selected_command, "#1e293b", full=True).pack(fill="x", pady=4)
        self._make_action_button(actions, "Copier le nom", self.copy_selected_name, "#1e293b", full=True).pack(fill="x", pady=4)
        self._make_action_button(actions, "Ouvrir le dossier", self.open_selected_folder, "#1e293b", full=True).pack(fill="x", pady=4)
        self._make_action_button(actions, "Tout sélectionner", self.select_all, "#1e293b", full=True).pack(fill="x", pady=4)
        self._make_action_button(actions, "Tout désélectionner", self.clear_selection, "#1e293b", full=True).pack(fill="x", pady=4)

        tips = tk.Frame(master, bg=PANEL_BG, highlightthickness=1, highlightbackground=BORDER)
        tips.pack(fill="x", padx=16, pady=(8, 16))
        tk.Label(tips, text="Conseils", bg=PANEL_BG, fg=TEXT, font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=12, pady=(12, 6))
        tk.Label(
            tips,
            text="• Double-clic sur une ligne : voir la commande\n• Clic droit : menu rapide\n• Utilise de préférence le mode administrateur pour certaines désinstallations",
            bg=PANEL_BG,
            fg=MUTED,
            justify="left",
            font=("Segoe UI", 9),
        ).pack(anchor="w", padx=12, pady=(0, 12))

    def _make_action_button(self, master, text, command, bg_color, full=False):
        label = tk.Label(
            master,
            text=text,
            bg=bg_color,
            fg="white",
            font=("Segoe UI", 10, "bold"),
            padx=14,
            pady=8,
            cursor="hand2",
            relief="flat",
        )
        hover = bg_color if bg_color == ACCENT else "#2a3959"
        label.bind("<Button-1>", lambda _e: command())
        label.bind("<Enter>", lambda _e: label.config(bg=hover))
        label.bind("<Leave>", lambda _e: label.config(bg=bg_color))
        if full:
            label.config(anchor="center")
        return label

    def set_status(self, text: str):
        self.status_var.set(text)

    def refresh_programs(self):
        if os.name != "nt" or winreg is None:
            messagebox.showerror("Système non compatible", "Ce logiciel fonctionne uniquement sous Windows.")
            self.set_status("Système non compatible")
            return
        self.set_status("Analyse du registre Windows en cours...")
        threading.Thread(target=self._load_programs_worker, daemon=True).start()

    def _load_programs_worker(self):
        try:
            self.worker_queue.put(("programs_loaded", load_installed_programs()))
        except Exception as exc:
            self.worker_queue.put(("error", str(exc)))

    def _poll_worker_queue(self):
        try:
            while True:
                kind, payload = self.worker_queue.get_nowait()
                if kind == "programs_loaded":
                    self.programs = payload
                    self.apply_filters()
                    self.set_status(f"{len(self.programs)} entrée(s) détectée(s)")
                elif kind == "error":
                    messagebox.showerror("Erreur", payload)
                    self.set_status("Erreur pendant le chargement")
        except queue.Empty:
            pass
        self.after(120, self._poll_worker_queue)

    def apply_filters(self):
        query = self.search_var.get().strip().lower()
        scope_filter = self.scope_var.get()
        filtered: list[ProgramEntry] = []
        for program in self.programs:
            haystack = " ".join([
                program.name,
                program.version,
                program.publisher,
                program.install_location,
                program.scope,
                program.registry_key,
            ]).lower()
            if query and query not in haystack:
                continue
            if self.only_with_uninstall_var.get() and not program.has_uninstall:
                continue
            if self.hide_updates_var.get() and looks_like_update(program.name):
                continue
            if self.hide_microsoft_var.get() and looks_like_microsoft(program.publisher, program.name):
                continue
            if scope_filter != "Tous" and program.scope != scope_filter:
                continue
            filtered.append(program)

        self.filtered_programs = filtered
        self._sort_filtered_programs()
        self._populate_tree()
        self._update_summary_cards()
        self.quick_stats_var.set(f"{len(self.filtered_programs)} programme(s) visible(s) sur {len(self.programs)} détecté(s)")
        self.set_status(f"{len(self.filtered_programs)} programme(s) affiché(s) sur {len(self.programs)}")

    def _sort_filtered_programs(self):
        key_map = {
            "name": lambda p: (p.name or "").lower(),
            "version": lambda p: (p.version or "").lower(),
            "publisher": lambda p: (p.publisher or "").lower(),
            "scope": lambda p: (p.scope or "").lower(),
            "size": lambda p: p.estimated_size_mb if p.estimated_size_mb is not None else -1,
            "location": lambda p: (p.install_location or "").lower(),
        }
        self.filtered_programs.sort(key=key_map.get(self.sort_column, key_map["name"]), reverse=self.sort_reverse)

    def sort_by_column(self, column: str):
        if self.sort_column == column:
            self.sort_reverse = not self.sort_reverse
        else:
            self.sort_column = column
            self.sort_reverse = False
        self.apply_filters()

    def _populate_tree(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        self.row_to_program.clear()
        for idx, program in enumerate(self.filtered_programs):
            iid = f"row_{idx}"
            tag = "even" if idx % 2 == 0 else "odd"
            self.tree.insert(
                "",
                "end",
                iid=iid,
                values=(
                    program.name,
                    program.version or "—",
                    program.publisher or "—",
                    program.scope or "—",
                    program.size_label(),
                    program.install_location or "—",
                ),
                tags=(tag,),
            )
            self.row_to_program[iid] = program
        self.on_selection_change()

    def _update_summary_cards(self):
        ready_count = sum(1 for p in self.filtered_programs if p.has_uninstall)
        total_size = sum(p.estimated_size_mb or 0 for p in self.filtered_programs)
        size_label = f"{total_size / 1024:.1f} Go" if total_size >= 1024 else f"{total_size:.0f} Mo"
        self.card_total.update_values(str(len(self.filtered_programs)), "Liste filtrée")
        self.card_ready.update_values(str(ready_count), "Commandes disponibles")
        self.card_size.update_values(size_label, "Somme visible")
        self._update_selection_card()

    def _update_selection_card(self):
        selected = self.get_selected_programs()
        if not selected:
            self.card_selected.update_values("0", "Aucun élément")
            return
        uninstallable = sum(1 for p in selected if p.has_uninstall)
        subtitle = f"{uninstallable} désinstallable(s)" if len(selected) > 1 else "Prêt à agir"
        self.card_selected.update_values(str(len(selected)), subtitle)

    def get_selected_programs(self) -> list[ProgramEntry]:
        selected: list[ProgramEntry] = []
        for iid in self.tree.selection():
            program = self.row_to_program.get(iid)
            if program:
                selected.append(program)
        return selected

    def on_selection_change(self, _event=None):
        selected = self.get_selected_programs()
        count = len(selected)
        self.selection_count_var.set(f"{count} sélection(s)")
        self._update_selection_card()
        if not selected:
            self.details_title_var.set("Aucun programme sélectionné")
            self.details_var.set("Sélectionne un programme pour afficher ses informations détaillées.")
            return

        p = selected[0]
        lines = [
            f"Version : {p.version or 'Inconnue'}",
            f"Éditeur : {p.publisher or 'Inconnu'}",
            f"Portée : {p.scope or 'Inconnue'}",
            f"Taille estimée : {p.size_label()}",
            f"Dossier : {p.install_location or 'Non indiqué'}",
            f"Clé registre : {p.registry_key or 'Non indiquée'}",
            f"Commande : {p.effective_uninstall_command() or 'Aucune'}",
        ]
        if count > 1:
            lines.append(f"\nSélection multiple : {count} élément(s)")
        self.details_title_var.set(p.name)
        self.details_var.set("\n".join(lines))

    def show_context_menu(self, event):
        row_id = self.tree.identify_row(event.y)
        if row_id and row_id not in self.tree.selection():
            self.tree.selection_set(row_id)
            self.on_selection_change()
        if row_id:
            self.context_menu.tk_popup(event.x_root, event.y_root)

    def select_all(self):
        self.tree.selection_set(self.tree.get_children())
        self.on_selection_change()

    def clear_selection(self):
        self.tree.selection_remove(self.tree.selection())
        self.on_selection_change()

    def export_csv(self):
        path = filedialog.asksaveasfilename(
            title="Exporter la liste",
            defaultextension=".csv",
            filetypes=[("CSV", "*.csv")],
            initialfile="programmes_installes.csv",
        )
        if not path:
            return
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as file:
                writer = csv.writer(file, delimiter=';')
                writer.writerow(["Programme", "Version", "Éditeur", "Portée", "Taille", "Dossier", "Commande"])
                for p in self.filtered_programs:
                    writer.writerow([
                        p.name,
                        p.version,
                        p.publisher,
                        p.scope,
                        p.size_label(),
                        p.install_location,
                        p.effective_uninstall_command(),
                    ])
            messagebox.showinfo("Export terminé", f"Fichier enregistré :\n{path}")
            self.set_status("Export CSV terminé")
        except Exception as exc:
            messagebox.showerror("Erreur d'export", str(exc))

    def open_selected_folder(self):
        selected = self.get_selected_programs()
        if not selected:
            messagebox.showwarning("Aucune sélection", "Sélectionne un programme.")
            return
        folder = selected[0].install_location
        if not folder or not os.path.isdir(folder):
            messagebox.showinfo("Dossier introuvable", "Aucun dossier d'installation exploitable n'a été trouvé.")
            return
        os.startfile(folder)

    def show_selected_command(self):
        selected = self.get_selected_programs()
        if not selected:
            messagebox.showwarning("Aucune sélection", "Sélectionne un programme.")
            return
        program = selected[0]
        cmd = program.effective_uninstall_command()
        if not cmd:
            messagebox.showinfo("Commande absente", "Aucune commande de désinstallation n'est disponible pour ce programme.")
            return
        messagebox.showinfo(f"Commande - {program.name}", cmd)

    def copy_selected_name(self):
        selected = self.get_selected_programs()
        if not selected:
            messagebox.showwarning("Aucune sélection", "Sélectionne un programme.")
            return
        self.clipboard_clear()
        self.clipboard_append(selected[0].name)
        self.set_status("Nom du programme copié")

    def copy_selected_command(self):
        selected = self.get_selected_programs()
        if not selected:
            messagebox.showwarning("Aucune sélection", "Sélectionne un programme.")
            return
        cmd = selected[0].effective_uninstall_command()
        if not cmd:
            messagebox.showinfo("Commande absente", "Aucune commande de désinstallation n'est disponible pour ce programme.")
            return
        self.clipboard_clear()
        self.clipboard_append(cmd)
        self.set_status("Commande copiée dans le presse-papiers")

    def uninstall_selected(self):
        selected = self.get_selected_programs()
        if not selected:
            messagebox.showwarning("Aucune sélection", "Sélectionne au moins un programme à désinstaller.")
            return

        unavailable = [p.name for p in selected if not p.has_uninstall]
        if unavailable:
            messagebox.showwarning(
                "Entrées ignorées",
                "Certaines entrées n'ont pas de commande de désinstallation et seront ignorées :\n\n- " + "\n- ".join(unavailable[:12]),
            )
            selected = [p for p in selected if p.has_uninstall]
        if not selected:
            return

        if len(selected) == 1:
            message = (
                f"Lancer la désinstallation de ce programme ?\n\n{selected[0].name}\n\n"
                "Le logiciel va exécuter la commande officielle enregistrée par Windows."
            )
        else:
            names = "\n".join(f"- {p.name}" for p in selected[:12])
            more = "\n..." if len(selected) > 12 else ""
            message = (
                f"Lancer {len(selected)} désinstallations ?\n\n{names}{more}\n\n"
                "Chaque désinstallation peut ouvrir sa propre fenêtre."
            )

        if not messagebox.askyesno("Confirmation", message):
            return

        launched = 0
        errors = []
        for program in selected:
            cmd = normalize_uninstall_command(program.effective_uninstall_command())
            try:
                subprocess.Popen(cmd, shell=True)
                launched += 1
            except Exception as exc:
                errors.append(f"{program.name} : {exc}")

        if launched:
            messagebox.showinfo("Désinstallations lancées", f"{launched} désinstallation(s) lancée(s).")
        if errors:
            messagebox.showerror("Erreurs", "\n".join(errors[:10]))
        self.set_status(f"{launched} désinstallation(s) lancée(s)")

    def show_about(self):
        messagebox.showinfo(
            "À propos",
            f"{APP_TITLE} {APP_VERSION}\n\n"
            "Interface premium en Tkinter pour lister et désinstaller plus facilement des programmes sous Windows.\n\n"
            "Le logiciel utilise les commandes de désinstallation présentes dans le registre Windows.",
        )


def looks_like_update(name: str) -> bool:
    value = (name or "").lower()
    patterns = [
        "security update",
        "hotfix",
        "update for",
        "kb",
        "redistributable update",
        "mise à jour",
        "cumulative update",
        ".net framework",
        "servicing stack",
    ]
    return any(p in value for p in patterns)


def looks_like_microsoft(publisher: str, name: str) -> bool:
    haystack = f"{publisher} {name}".lower()
    return "microsoft" in haystack or "windows" in haystack


def strip_control_chars(value: str) -> str:
    return re.sub(r"[\x00-\x1f]+", " ", value or "").strip()


def normalize_uninstall_command(cmd: str) -> str:
    cmd = (cmd or "").strip()
    if not cmd:
        return cmd
    cmd = cmd.replace("/I{", "/X{")
    if cmd.lower().startswith("msiexec") and "/x" not in cmd.lower():
        cmd = re.sub(r"(?i)\s+/i(\s+|\{)", r" /X\1", cmd, count=1)
    return cmd


def get_reg_value(key, name):
    try:
        value, _ = winreg.QueryValueEx(key, name)
        if isinstance(value, str):
            return strip_control_chars(value)
        return value
    except OSError:
        return ""


def estimated_size_mb_from_registry(raw_value) -> float | None:
    if raw_value in ("", None):
        return None
    try:
        kb_value = int(raw_value)
        if kb_value <= 0:
            return None
        return kb_value / 1024
    except (TypeError, ValueError):
        return None


def enum_uninstall_roots():
    access_modes = [0]
    if hasattr(winreg, "KEY_WOW64_64KEY"):
        access_modes.append(winreg.KEY_WOW64_64KEY)
    if hasattr(winreg, "KEY_WOW64_32KEY"):
        access_modes.append(winreg.KEY_WOW64_32KEY)

    roots = [
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", "Machine"),
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", "Utilisateur"),
    ]
    for hive, path, scope in roots:
        for wow_flag in access_modes:
            yield hive, path, scope, wow_flag


def load_installed_programs() -> list[ProgramEntry]:
    found: dict[tuple[str, str, str], ProgramEntry] = {}
    for hive, path, scope, wow_flag in enum_uninstall_roots():
        try:
            root = winreg.OpenKey(hive, path, 0, winreg.KEY_READ | wow_flag)
        except OSError:
            continue
        try:
            count = winreg.QueryInfoKey(root)[0]
            for index in range(count):
                try:
                    subkey_name = winreg.EnumKey(root, index)
                    with winreg.OpenKey(root, subkey_name) as subkey:
                        display_name = get_reg_value(subkey, "DisplayName")
                        uninstall_cmd = get_reg_value(subkey, "UninstallString")
                        quiet_cmd = get_reg_value(subkey, "QuietUninstallString")
                        if not display_name:
                            continue

                        system_component = str(get_reg_value(subkey, "SystemComponent")).strip()
                        parent_key = get_reg_value(subkey, "ParentKeyName")
                        release_type = get_reg_value(subkey, "ReleaseType")
                        if system_component == "1" or parent_key or str(release_type).lower() == "update":
                            continue

                        version = get_reg_value(subkey, "DisplayVersion")
                        publisher = get_reg_value(subkey, "Publisher")
                        install_location = get_reg_value(subkey, "InstallLocation")
                        estimated_size_mb = estimated_size_mb_from_registry(get_reg_value(subkey, "EstimatedSize"))
                        unique_key = (display_name.lower(), (version or "").lower(), (publisher or "").lower())
                        if unique_key in found:
                            continue

                        found[unique_key] = ProgramEntry(
                            name=display_name,
                            version=version,
                            publisher=publisher,
                            uninstall_cmd=uninstall_cmd,
                            quiet_cmd=quiet_cmd,
                            install_location=install_location,
                            scope=scope,
                            registry_key=subkey_name,
                            estimated_size_mb=estimated_size_mb,
                        )
                except OSError:
                    continue
        finally:
            winreg.CloseKey(root)

    programs = list(found.values())
    programs.sort(key=lambda p: p.name.lower())
    return programs


def main():
    app = UninstallerApp()
    app.mainloop()


if __name__ == "__main__":
    main()
