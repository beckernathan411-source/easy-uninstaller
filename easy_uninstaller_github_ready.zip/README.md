# Easy Uninstaller Premium

Easy Uninstaller Premium est une application Windows en Python avec interface graphique pour lister les programmes installés et lancer leur désinstallation officielle plus facilement.

## Fonctions

- Interface sombre premium
- Recherche instantanée
- Tri par colonnes
- Filtres Tous / Machine / Utilisateur
- Masquer Microsoft
- Masquer les mises à jour système
- Désinstallation simple ou multiple
- Copie du nom et de la commande
- Ouverture du dossier d'installation
- Export CSV

## Structure du dépôt

```text
.
├─ .github/workflows/build-installer.yml
├─ main.py
├─ app_icon.ico
├─ easy_uninstaller.spec
├─ installer.iss
├─ build_exe.bat
├─ requirements.txt
├─ .gitignore
└─ README.md
```

## Lancer localement

Sur Windows :

```powershell
py -m pip install -r requirements.txt
py main.py
```

## Créer le .exe localement

```powershell
py -m pip install --upgrade pip pyinstaller
py -m PyInstaller --noconfirm --clean easy_uninstaller.spec
```

Le fichier généré sera dans `dist\EasyUninstallerPremium.exe`.

## Créer l'installer `.exe` localement

1. Installe **Inno Setup 6** sur Windows.
2. Compile `installer.iss` avec Inno Setup.
3. Tu obtiendras un installateur dans `installer_output\EasyUninstallerPremiumSetup.exe`.

## Build automatique sur GitHub

Le workflow GitHub Actions :

- construit l'application avec **PyInstaller**
- construit l'installateur avec **Inno Setup**
- publie les deux artefacts téléchargeables dans l'onglet **Actions**
- peut aussi créer une **Release GitHub** si tu lances le workflow avec un tag

### Mise en ligne

```powershell
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/TON-USER/TON-REPO.git
git push -u origin main
```

### Lancer le workflow

- soit automatiquement sur `push` et `pull_request`
- soit manuellement via **Actions > Build Windows Installer > Run workflow**

## Important

- compatible **Windows uniquement**
- le logiciel exécute les commandes de désinstallation déjà enregistrées par Windows
- certaines désinstallations demandent des droits administrateur

## Licence

Aucune licence n'est incluse par défaut. Ajoute celle que tu veux pour GitHub si tu souhaites autoriser la réutilisation.
