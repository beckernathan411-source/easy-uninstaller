@echo off
setlocal

echo [1/2] Installation / mise a jour des outils...
py -m pip install --upgrade pip pyinstaller
if errorlevel 1 goto :error

echo [2/2] Generation du .exe...
py -m PyInstaller --noconfirm --clean easy_uninstaller.spec
if errorlevel 1 goto :error

echo.
echo Termine.
echo Executable genere : dist\EasyUninstallerPremium.exe
pause
exit /b 0

:error
echo.
echo Une erreur est survenue pendant la generation du .exe.
pause
exit /b 1
